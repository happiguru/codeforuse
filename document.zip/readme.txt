* Email: contact@botble.com
* Website: botble.com
* Support center: https://botble.ticksy.com
* Online documentation: https://docs.botble.com/stories
* User guide: https://www.evernote.com/l/AUdC_0EKhNJL26AAmQX7uxc-QyqdgoAFS94
